function convertTemperature() {
    const tempInput = document.getElementById('temperature').value;
    const unitFrom = document.getElementById('unitFrom').value;
    const unitTo = document.getElementById('unitTo').value;
    let result = '';

    if (!tempInput || isNaN(tempInput)) {
        result = 'Please enter a valid number';
    } else {
        const temp = parseFloat(tempInput);

        if (unitFrom === unitTo) {
            result = `${temp} ${unitTo}`;
        } else {
            let celsius;

            if (unitFrom === 'Fahrenheit') {
                celsius = (temp - 32) * 5 / 9;
            } else if (unitFrom === 'Kelvin') {
                celsius = temp - 273.15;
            } else {
                celsius = temp;
            }
            if (unitTo === 'Fahrenheit') {
                result = `${(celsius * 9 / 5 + 32).toFixed(2)} °F`;
            } else if (unitTo === 'Kelvin') {
                result = `${(celsius + 273.15).toFixed(2)} K`;
            } else {
                result = `${celsius.toFixed(2)} °C`;
            }
        }
    }

    document.getElementById('result').textContent = result;
}
